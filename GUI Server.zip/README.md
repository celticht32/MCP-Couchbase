# Couchbase MCP Console — GUI

A web-based interface for the Couchbase MCP Server.
Browse and execute all 105 admin + data tools from your browser.

## Features

- 🗂 **Sidebar navigation** — all 105 tools organized into 9 categories (Data, Buckets, Collections, Security, Cluster, XDCR, Indexes, FTS Admin, Stats)
- 🔍 **Live search** — filter tools instantly by name or description
- 📋 **Auto-generated forms** — input fields are generated from each tool's JSON schema, with type-aware widgets (booleans → toggle buttons, enums → dropdowns, objects/arrays → JSON editors)
- ✅ **Syntax-highlighted JSON output** — color-coded responses with table view for arrays
- ⏱ **Execution timing** — shows ms elapsed for each call
- 🕘 **History strip** — last 10 calls accessible in one click
- ⚙️ **Connection settings modal** — change CB_CONNECTION_STRING, credentials, bucket, etc. at runtime

## Quick Start

```bash
# From the couchbase-mcp-server directory:
pip install flask flask-cors

# Set your connection details (optional — also configurable in the GUI):
export CB_CONNECTION_STRING=couchbase://localhost
export CB_USERNAME=Administrator
export CB_PASSWORD=password
export CB_BUCKET=travel-sample

# Run the GUI server:
python gui/gui_server.py
# → http://localhost:5173
```

## File Structure

```
gui/
├── gui_server.py      # Flask backend — wraps the MCP handlers as REST endpoints
├── static/
│   └── index.html     # Complete React SPA (single file, no build step required)
└── README.md
```

## API Endpoints (Backend)

| Method | Path         | Description |
|--------|-------------|-------------|
| GET    | `/api/tools` | List all 105 tools with their schemas |
| POST   | `/api/call`  | Execute a tool: `{ "tool": "cb_ping", "arguments": {} }` |
| GET    | `/api/config`| Get current connection environment variables |
| POST   | `/api/config`| Update connection variables and reset SDK connection |
| GET    | `/`          | Serve the React SPA |

## Configuration

All connection settings map to the same environment variables as the MCP server:

| Variable | Default | Description |
|---|---|---|
| `CB_CONNECTION_STRING` | `couchbase://localhost` | Use `couchbases://` for TLS |
| `CB_USERNAME` | `Administrator` | |
| `CB_PASSWORD` | `password` | |
| `CB_BUCKET` | `default` | Default bucket for data ops |
| `CB_SCOPE` | `_default` | |
| `CB_COLLECTION` | `_default` | |
| `CB_MGMT_PORT` | `8091` | |
| `GUI_PORT` | `5173` | Port the Flask server listens on |

## Notes

- The GUI server imports the MCP handler modules directly — no separate MCP process needed.
- The frontend is a single HTML file with no build step: React and fonts load from CDN.
- For Couchbase Capella, set `CB_CONNECTION_STRING=couchbases://...` and `CB_MGMT_PORT=18091`.
