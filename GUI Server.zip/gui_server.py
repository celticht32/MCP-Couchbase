"""
gui_server.py – Flask backend for the Couchbase MCP GUI.

Imports the MCP handler modules directly and exposes them via a REST API
that the browser frontend can call. No MCP transport layer needed.

Run:
    cd /path/to/couchbase-mcp-server
    python gui/gui_server.py
"""

import sys
import os
import json

# Add the MCP server root to the path
SERVER_ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.abspath(SERVER_ROOT))

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Import all handler modules
from handlers import (
    data, buckets, collections, security,
    cluster, xdcr, indexes, search_admin, stats,
)

app = Flask(__name__, static_folder="static")
CORS(app)

# ── Tool registry (mirrors server.py) ────────────────────────────────────────
ALL_TOOLS = (
    data.TOOLS + buckets.TOOLS + collections.TOOLS + security.TOOLS +
    cluster.TOOLS + xdcr.TOOLS + indexes.TOOLS + search_admin.TOOLS + stats.TOOLS
)

HANDLERS = {
    **{t.name: data         for t in data.TOOLS},
    **{t.name: buckets      for t in buckets.TOOLS},
    **{t.name: collections  for t in collections.TOOLS},
    **{t.name: security     for t in security.TOOLS},
    **{t.name: cluster      for t in cluster.TOOLS},
    **{t.name: xdcr         for t in xdcr.TOOLS},
    **{t.name: indexes      for t in indexes.TOOLS},
    **{t.name: search_admin for t in search_admin.TOOLS},
    **{t.name: stats        for t in stats.TOOLS},
}

TOOL_INDEX = {t.name: t for t in ALL_TOOLS}


# ── API endpoints ─────────────────────────────────────────────────────────────

@app.route("/api/tools", methods=["GET"])
def list_tools():
    """Return all tools with their schemas."""
    result = []
    for tool in ALL_TOOLS:
        result.append({
            "name":        tool.name,
            "description": tool.description,
            "inputSchema": tool.inputSchema,
        })
    return jsonify(result)


@app.route("/api/call", methods=["POST"])
def call_tool():
    """Execute a tool and return the result."""
    body       = request.get_json(force=True)
    tool_name  = body.get("tool")
    arguments  = body.get("arguments", {})

    if not tool_name:
        return jsonify({"error": "Missing 'tool' field"}), 400

    handler = HANDLERS.get(tool_name)
    if handler is None:
        return jsonify({"error": f"Unknown tool: {tool_name}"}), 404

    try:
        result  = handler.handle(tool_name, arguments)
        text    = result[0].text if result else "{}"
        parsed  = json.loads(text)
        return jsonify({"ok": True, "result": parsed})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 200


@app.route("/api/config", methods=["GET", "POST"])
def config():
    """Get or set environment-level connection config."""
    if request.method == "POST":
        body = request.get_json(force=True)
        for key, val in body.items():
            if val:
                os.environ[key] = val
        # Reset SDK connection so next call re-connects
        import handlers.shared as sh
        sh._cluster = sh._bucket = sh._collection = None
        return jsonify({"ok": True})
    else:
        return jsonify({
            "CB_CONNECTION_STRING": os.environ.get("CB_CONNECTION_STRING", "couchbase://localhost"),
            "CB_USERNAME":          os.environ.get("CB_USERNAME", "Administrator"),
            "CB_PASSWORD":          os.environ.get("CB_PASSWORD", ""),
            "CB_BUCKET":            os.environ.get("CB_BUCKET", "default"),
            "CB_SCOPE":             os.environ.get("CB_SCOPE", "_default"),
            "CB_COLLECTION":        os.environ.get("CB_COLLECTION", "_default"),
            "CB_MGMT_PORT":         os.environ.get("CB_MGMT_PORT", "8091"),
        })


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_frontend(path):
    """Serve the React SPA."""
    if path and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    port = int(os.environ.get("GUI_PORT", 5173))
    print(f"\n  Couchbase MCP GUI → http://localhost:{port}\n")
    app.run(host="0.0.0.0", port=port, debug=True)
