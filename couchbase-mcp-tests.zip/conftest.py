"""
conftest.py – shared pytest fixtures for the Couchbase MCP Server test suite.

Key design: handlers import functions directly via `from .shared import admin_request`,
so we must patch the name at the usage site (e.g. handlers.buckets.admin_request),
not just in handlers.shared.
"""

from __future__ import annotations

import json
import sys
import os
import types
from unittest.mock import MagicMock, patch
import pytest

# Make project root importable
ROOT = os.path.dirname(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


# ── Stub the heavy couchbase SDK ─────────────────────────────────────────────
def _make_couchbase_stub():
    cb      = types.ModuleType("couchbase")
    opts    = types.ModuleType("couchbase.options")
    auth    = types.ModuleType("couchbase.auth")
    clust   = types.ModuleType("couchbase.cluster")
    search  = types.ModuleType("couchbase.search")
    vsearch = types.ModuleType("couchbase.vector_search")

    for name in ("ClusterOptions", "PasswordAuthenticator", "Cluster",
                 "QueryOptions", "SearchOptions", "MatchQuery",
                 "HighlightStyle", "VectorQuery", "VectorSearch"):
        for mod in (opts, auth, clust, search, vsearch):
            setattr(mod, name, MagicMock())

    cb.options = opts; cb.auth = auth; cb.cluster = clust
    cb.search = search; cb.vector_search = vsearch

    for key, mod in {
        "couchbase": cb, "couchbase.options": opts, "couchbase.auth": auth,
        "couchbase.cluster": clust, "couchbase.search": search,
        "couchbase.vector_search": vsearch,
    }.items():
        sys.modules.setdefault(key, mod)


_make_couchbase_stub()


# ── Response parser helper ────────────────────────────────────────────────────
def parse_response(result) -> dict:
    assert result, "handler returned empty list"
    return json.loads(result[0].text)


# ── SDK mock fixtures ─────────────────────────────────────────────────────────

@pytest.fixture()
def mock_collection():
    col = MagicMock()

    get_result = MagicMock()
    get_result.content_as.__getitem__ = MagicMock(return_value={"foo": "bar"})
    col.get.return_value = get_result

    mut_result = MagicMock()
    mut_result.cas = 12345
    col.upsert.return_value  = mut_result
    col.insert.return_value  = mut_result
    col.replace.return_value = mut_result

    multi_item = MagicMock()
    multi_item.success = True
    multi_item.content_as.__getitem__ = MagicMock(return_value={"x": 1})
    multi_result = MagicMock()
    multi_result.results = {"k1": multi_item, "k2": multi_item}
    col.get_multi.return_value = multi_result
    return col


@pytest.fixture()
def mock_cluster(mock_collection):
    cluster = MagicMock()

    # ping
    ep = MagicMock(); ep.id = "ep-1"; ep.state = "ok"; ep.remote = "127.0.0.1"
    ping_result = MagicMock(); ping_result.endpoints = {"kv": [ep]}
    cluster.ping.return_value = ping_result

    # query
    metrics = MagicMock()
    metrics.elapsed_time.return_value   = "1ms"
    metrics.execution_time.return_value = "1ms"
    metrics.result_count.return_value   = 2
    meta = MagicMock(); meta.metrics.return_value = metrics
    query_result = MagicMock()
    query_result.__iter__ = MagicMock(return_value=iter([{"id": 1}, {"id": 2}]))
    query_result.metadata.return_value = meta
    cluster.query.return_value = query_result

    # search
    took = MagicMock(); took.total_seconds.return_value = 0.005
    s_metrics = MagicMock()
    s_metrics.total_rows.return_value = 1
    s_metrics.took.return_value = took
    s_meta = MagicMock(); s_meta.metrics.return_value = s_metrics
    hit = MagicMock()
    hit.id = "doc::1"; hit.score = 0.9; hit.fields = {"name": "test"}; hit.fragments = None
    search_result = MagicMock()
    search_result.__iter__ = MagicMock(return_value=iter([hit]))
    search_result.metadata.return_value = s_meta
    cluster.search.return_value = search_result
    return cluster


@pytest.fixture()
def sdk_mocks(mock_cluster, mock_collection):
    """
    Patch get_sdk_connection in every handler module that uses it.
    Returns (cluster, bucket, collection).
    """
    bucket = MagicMock()
    retval = (mock_cluster, bucket, mock_collection)

    targets = [
        "handlers.data.get_sdk_connection",
        "handlers.indexes.get_sdk_connection",
        "handlers.shared.get_sdk_connection",
    ]
    # Reset module-level SDK cache
    import handlers.shared as sh
    sh._cluster = sh._bucket = sh._collection = None

    patchers = [patch(t, return_value=retval) for t in targets]
    mocks = [p.start() for p in patchers]
    yield retval
    for p in patchers:
        p.stop()


# ── Admin HTTP mock fixtures ──────────────────────────────────────────────────

# All modules that call admin_request / admin_request_json by direct import
_ADMIN_MODULES = [
    "handlers.buckets",
    "handlers.collections",
    "handlers.security",
    "handlers.cluster",
    "handlers.xdcr",
    "handlers.indexes",
    "handlers.search_admin",
    "handlers.stats",
    "handlers.shared",   # for test_shared.py tests that go through shared directly
]


@pytest.fixture()
def admin_mock():
    """
    Patch admin_request in every handler module.
    Returns the mock for admin_request (the most-used one).
    Also exposes .json attribute pointing to the admin_request_json mock.
    """
    ar_mock  = MagicMock(return_value={"status": "ok"})
    arj_mock = MagicMock(return_value={"status": "ok"})

    patchers = []
    for mod in _ADMIN_MODULES:
        patchers.append(patch(f"{mod}.admin_request",      ar_mock))
    # also patch admin_request_json in modules that use it
    for mod in ("handlers.stats", "handlers.search_admin", "handlers.shared"):
        patchers.append(patch(f"{mod}.admin_request_json", arj_mock))

    for p in patchers:
        try:
            p.start()
        except AttributeError:
            pass   # module doesn't have that name — skip silently

    ar_mock.json = arj_mock
    yield ar_mock

    for p in patchers:
        try:
            p.stop()
        except RuntimeError:
            pass
