"""tests/test_data.py – Unit tests for handlers/data.py (CRUD, N1QL, FTS, ping)"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

import handlers.data as data_handler
from conftest import parse_response


# Every test in this module needs the SDK mocked


# ── cb_ping ───────────────────────────────────────────────────────────────────

class TestCbPing:
    def test_returns_ok_status(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_ping", {})
        data   = parse_response(result)
        assert data["status"] == "ok"

    def test_lists_services(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_ping", {})
        data   = parse_response(result)
        assert "services" in data
        assert "kv" in data["services"]

    def test_service_endpoints_contain_expected_fields(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_ping", {})
        data   = parse_response(result)
        ep = data["services"]["kv"][0]
        assert "id" in ep
        assert "state" in ep
        assert "remote" in ep


# ── cb_get ────────────────────────────────────────────────────────────────────

class TestCbGet:
    def test_returns_document_content(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_get", {"key": "doc::1"})
        data   = parse_response(result)
        assert data["key"] == "doc::1"
        assert "content" in data

    def test_calls_collection_get_with_correct_key(self, sdk_mocks):
        _, _, col = sdk_mocks
        data_handler.handle("cb_get", {"key": "mykey"})
        col.get.assert_called_once_with("mykey")

    def test_error_propagates_as_exception(self, sdk_mocks):
        _, _, col = sdk_mocks
        col.get.side_effect = Exception("DocumentNotFoundError")
        with pytest.raises(Exception, match="DocumentNotFoundError"):
            data_handler.handle("cb_get", {"key": "missing"})


# ── cb_upsert ─────────────────────────────────────────────────────────────────

class TestCbUpsert:
    def test_returns_upsert_operation(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_upsert", {"key": "k", "document": {"a": 1}})
        data   = parse_response(result)
        assert data["operation"] == "upsert"
        assert data["key"] == "k"

    def test_returns_cas(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_upsert", {"key": "k", "document": {}})
        data   = parse_response(result)
        assert "cas" in data

    def test_passes_document_to_collection(self, sdk_mocks):
        _, _, col = sdk_mocks
        doc = {"name": "Alice", "age": 30}
        data_handler.handle("cb_upsert", {"key": "user::1", "document": doc})
        col.upsert.assert_called_once_with("user::1", doc)


# ── cb_insert ─────────────────────────────────────────────────────────────────

class TestCbInsert:
    def test_returns_insert_operation(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_insert", {"key": "k", "document": {"x": 1}})
        data   = parse_response(result)
        assert data["operation"] == "insert"

    def test_calls_collection_insert(self, sdk_mocks):
        _, _, col = sdk_mocks
        data_handler.handle("cb_insert", {"key": "new::1", "document": {}})
        col.insert.assert_called_once()


# ── cb_replace ────────────────────────────────────────────────────────────────

class TestCbReplace:
    def test_returns_replace_operation(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_replace", {"key": "k", "document": {}})
        data   = parse_response(result)
        assert data["operation"] == "replace"

    def test_calls_collection_replace(self, sdk_mocks):
        _, _, col = sdk_mocks
        data_handler.handle("cb_replace", {"key": "k", "document": {"updated": True}})
        col.replace.assert_called_once()


# ── cb_delete ─────────────────────────────────────────────────────────────────

class TestCbDelete:
    def test_returns_delete_status(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_delete", {"key": "doc::1"})
        data   = parse_response(result)
        assert data["operation"] == "delete"
        assert data["status"] == "ok"
        assert data["key"] == "doc::1"

    def test_calls_remove_on_collection(self, sdk_mocks):
        _, _, col = sdk_mocks
        data_handler.handle("cb_delete", {"key": "remove_me"})
        col.remove.assert_called_once_with("remove_me")


# ── cb_get_multi ──────────────────────────────────────────────────────────────

class TestCbGetMulti:
    def test_returns_dict_of_results(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_get_multi", {"keys": ["k1", "k2"]})
        data   = parse_response(result)
        assert "k1" in data
        assert "k2" in data

    def test_successful_key_has_content(self, sdk_mocks):
        _, _, col = sdk_mocks
        result = data_handler.handle("cb_get_multi", {"keys": ["k1"]})
        data   = parse_response(result)
        assert "content" in data["k1"]

    def test_failed_key_has_error(self, sdk_mocks):
        _, _, col = sdk_mocks
        fail_item = MagicMock()
        fail_item.success   = False
        fail_item.exception = Exception("not found")
        multi_result        = MagicMock()
        multi_result.results = {"bad_key": fail_item}
        col.get_multi.return_value = multi_result

        result = data_handler.handle("cb_get_multi", {"keys": ["bad_key"]})
        data   = parse_response(result)
        assert "error" in data["bad_key"]


# ── cb_query ──────────────────────────────────────────────────────────────────

class TestCbQuery:
    def test_returns_rows_and_count(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_query", {"statement": "SELECT 1"})
        data   = parse_response(result)
        assert "rows" in data
        assert "count" in data
        assert data["count"] == len(data["rows"])

    def test_returns_metrics(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_query", {"statement": "SELECT 1"})
        data   = parse_response(result)
        assert "metrics" in data
        m = data["metrics"]
        assert "elapsed" in m
        assert "execution" in m
        assert "result_count" in m

    def test_passes_named_params(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        data_handler.handle("cb_query", {
            "statement": "SELECT * FROM `b` WHERE x=$x",
            "params":    {"x": 42},
        })
        cluster.query.assert_called_once()
        call_args = cluster.query.call_args
        assert call_args[0][0] == "SELECT * FROM `b` WHERE x=$x"

    def test_readonly_flag_respected(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        data_handler.handle("cb_query", {
            "statement": "SELECT 1",
            "readonly":  True,
        })
        cluster.query.assert_called_once()

    def test_defaults_params_to_empty_dict(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        # Should not raise even with no params key
        result = data_handler.handle("cb_query", {"statement": "SELECT 1"})
        assert parse_response(result)


# ── cb_fts_search ─────────────────────────────────────────────────────────────

class TestCbFtsSearch:
    def test_returns_hits_and_total(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_fts_search", {
            "index_name": "my-index",
            "query":      "hello",
        })
        data = parse_response(result)
        assert "hits" in data
        assert "total_hits" in data
        assert "took_ms" in data

    def test_hit_has_id_and_score(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        result = data_handler.handle("cb_fts_search", {
            "index_name": "my-index",
            "query":      "hello",
        })
        data = parse_response(result)
        hit  = data["hits"][0]
        assert "id" in hit
        assert "score" in hit

    def test_uses_provided_limit(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        data_handler.handle("cb_fts_search", {
            "index_name": "idx",
            "query":      "q",
            "limit":      5,
        })
        cluster.search.assert_called_once()

    def test_includes_fields_when_provided(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        data_handler.handle("cb_fts_search", {
            "index_name": "idx",
            "query":      "q",
            "fields":     ["name", "city"],
        })
        cluster.search.assert_called_once()

    def test_unknown_tool_raises(self, sdk_mocks):
        with pytest.raises(ValueError, match="Unknown data tool"):
            data_handler.handle("cb_does_not_exist", {})


# ── Tool registration sanity ───────────────────────────────────────────────────

class TestToolRegistration:
    def test_all_tool_names_unique(self):
        names = [t.name for t in data_handler.TOOLS]
        assert len(names) == len(set(names))

    def test_expected_tools_present(self):
        names = {t.name for t in data_handler.TOOLS}
        expected = {"cb_ping", "cb_get", "cb_upsert", "cb_insert",
                    "cb_replace", "cb_delete", "cb_get_multi",
                    "cb_query", "cb_fts_search"}
        assert expected == names

    def test_all_tools_have_descriptions(self):
        for t in data_handler.TOOLS:
            assert t.description, f"{t.name} missing description"

    def test_required_fields_declared(self):
        for t in data_handler.TOOLS:
            schema = t.inputSchema
            if schema.get("required"):
                for field in schema["required"]:
                    assert field in schema.get("properties", {}), \
                        f"{t.name}: required field '{field}' not in properties"
