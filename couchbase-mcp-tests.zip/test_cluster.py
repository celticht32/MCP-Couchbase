"""tests/test_cluster.py – Unit tests for handlers/cluster.py"""

from __future__ import annotations

import pytest

import handlers.cluster as clust
from conftest import parse_response


# ── Cluster info ──────────────────────────────────────────────────────────────

class TestClusterInfo:
    def test_calls_pools_endpoint(self, admin_mock):
        admin_mock.return_value = {"pools": []}
        clust.handle("admin_cluster_info", {})
        admin_mock.assert_called_once_with("GET", "/pools")

    def test_calls_pool_default_for_details(self, admin_mock):
        clust.handle("admin_cluster_details", {})
        admin_mock.assert_called_once_with("GET", "/pools/default")

    def test_calls_tasks_endpoint(self, admin_mock):
        admin_mock.return_value = []
        clust.handle("admin_cluster_tasks", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/tasks")

    def test_rename_cluster_posts_name(self, admin_mock):
        clust.handle("admin_cluster_name_set", {"clusterName": "my-cluster"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert path   == "/pools/default"
        data = admin_mock.call_args[1]["data"]
        assert data["clusterName"] == "my-cluster"

    def test_set_memory_posts_to_pool_default(self, admin_mock):
        clust.handle("admin_cluster_memory_set", {"dataMemoryQuota": 1024})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert path == "/pools/default"

    def test_set_memory_excludes_none_values(self, admin_mock):
        clust.handle("admin_cluster_memory_set", {
            "dataMemoryQuota":  512,
            "indexMemoryQuota": None,
        })
        data = admin_mock.call_args[1]["data"]
        assert "indexMemoryQuota" not in data


# ── Nodes ─────────────────────────────────────────────────────────────────────

class TestNodes:
    def test_node_list_calls_pools_nodes(self, admin_mock):
        admin_mock.return_value = {"nodes": []}
        clust.handle("admin_node_list", {})
        admin_mock.assert_called_once_with("GET", "/pools/nodes")

    def test_node_services_list_endpoint(self, admin_mock):
        clust.handle("admin_node_services_list", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/nodeServices")

    def test_node_add_posts_to_addNode(self, admin_mock):
        clust.handle("admin_node_add", {
            "hostname": "10.0.0.5",
            "user":     "Administrator",
            "password": "pass",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "addNode" in path

    def test_node_add_includes_services_default(self, admin_mock):
        clust.handle("admin_node_add", {
            "hostname": "10.0.0.5",
            "user":     "Administrator",
            "password": "pass",
        })
        data = admin_mock.call_args[1]["data"]
        assert "services" in data
        assert data["services"] == "kv"

    def test_node_add_uses_provided_services(self, admin_mock):
        clust.handle("admin_node_add", {
            "hostname": "10.0.0.5",
            "user":     "Administrator",
            "password": "pass",
            "services": "kv,n1ql,index",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["services"] == "kv,n1ql,index"

    def test_node_remove_posts_ejectNode(self, admin_mock):
        clust.handle("admin_node_remove", {"otpNode": "ns_1@10.0.0.5"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "ejectNode" in path
        data = admin_mock.call_args[1]["data"]
        assert data["otpNode"] == "ns_1@10.0.0.5"


# ── Rebalance ─────────────────────────────────────────────────────────────────

class TestRebalance:
    def test_start_posts_to_rebalance(self, admin_mock):
        clust.handle("admin_rebalance_start", {})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "rebalance" in path

    def test_start_includes_ejected_nodes(self, admin_mock):
        clust.handle("admin_rebalance_start", {
            "ejectedNodes": "ns_1@10.0.0.5",
            "knownNodes":   "ns_1@10.0.0.4,ns_1@10.0.0.5",
        })
        data = admin_mock.call_args[1]["data"]
        assert "ejectedNodes" in data
        assert "knownNodes"   in data

    def test_progress_gets_progress_endpoint(self, admin_mock):
        admin_mock.return_value = {"status": "running"}
        clust.handle("admin_rebalance_progress", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/rebalanceProgress")

    def test_stop_posts_to_stop_endpoint(self, admin_mock):
        clust.handle("admin_rebalance_stop", {})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "stopRebalance" in path


# ── Failover ──────────────────────────────────────────────────────────────────

class TestFailover:
    def test_hard_failover_posts_failOver(self, admin_mock):
        clust.handle("admin_failover_hard", {"otpNode": "ns_1@10.0.0.5"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "failOver" in path
        data = admin_mock.call_args[1]["data"]
        assert data["otpNode"] == "ns_1@10.0.0.5"

    def test_graceful_failover_posts_graceful(self, admin_mock):
        clust.handle("admin_failover_graceful", {"otpNode": "ns_1@10.0.0.5"})
        _, path = admin_mock.call_args[0][:2]
        assert "startGracefulFailover" in path

    def test_recovery_type_posts_setRecoveryType(self, admin_mock):
        clust.handle("admin_recovery_type_set", {
            "otpNode":      "ns_1@10.0.0.5",
            "recoveryType": "delta",
        })
        _, path = admin_mock.call_args[0][:2]
        assert "setRecoveryType" in path
        data = admin_mock.call_args[1]["data"]
        assert data["recoveryType"] == "delta"


# ── Auto-Failover ─────────────────────────────────────────────────────────────

class TestAutoFailover:
    def test_get_retrieves_settings(self, admin_mock):
        clust.handle("admin_autofailover_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/autoFailover")

    def test_set_enabled_true(self, admin_mock):
        clust.handle("admin_autofailover_set", {"enabled": True, "timeout": 30})
        data = admin_mock.call_args[1]["data"]
        assert data["enabled"] == "true"
        assert data["timeout"] == "30"

    def test_set_enabled_false(self, admin_mock):
        clust.handle("admin_autofailover_set", {"enabled": False})
        data = admin_mock.call_args[1]["data"]
        assert data["enabled"] == "false"

    def test_reset_posts_to_reset_count(self, admin_mock):
        clust.handle("admin_autofailover_reset", {})
        _, path = admin_mock.call_args[0][:2]
        assert "resetCount" in path


# ── Server groups ─────────────────────────────────────────────────────────────

class TestServerGroups:
    def test_get_calls_endpoint(self, admin_mock):
        admin_mock.return_value = {"groups": []}
        clust.handle("admin_server_groups_get", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/serverGroups")

    def test_create_posts_name(self, admin_mock):
        clust.handle("admin_server_group_create", {"name": "rack-1"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        data = admin_mock.call_args[1]["data"]
        assert data["name"] == "rack-1"

    def test_delete_sends_delete_with_uuid(self, admin_mock):
        clust.handle("admin_server_group_delete", {"uuid": "abc-123"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "abc-123" in path

    def test_rename_puts_new_name(self, admin_mock):
        clust.handle("admin_server_group_rename", {"uuid": "abc-123", "name": "rack-2"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "PUT"
        assert "abc-123" in path
        data = admin_mock.call_args[1]["data"]
        assert data["name"] == "rack-2"


# ── Logging ───────────────────────────────────────────────────────────────────

class TestLogging:
    def test_collect_start_posts(self, admin_mock):
        clust.handle("admin_logs_collect_start", {"nodes": "all"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "startLogsCollection" in path

    def test_collect_start_passes_fields(self, admin_mock):
        clust.handle("admin_logs_collect_start", {
            "nodes":    "all",
            "customer": "acme",
            "ticket":   "CB-1234",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["customer"] == "acme"
        assert data["ticket"]   == "CB-1234"

    def test_collect_cancel_posts(self, admin_mock):
        clust.handle("admin_logs_collect_cancel", {})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "cancelLogsCollection" in path


# ── Auto-compaction ───────────────────────────────────────────────────────────

class TestAutoCompaction:
    def test_get_calls_endpoint(self, admin_mock):
        clust.handle("admin_autocompaction_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/autoCompaction")

    def test_set_posts_to_setAutoCompaction(self, admin_mock):
        clust.handle("admin_autocompaction_set", {
            "databaseFragmentationThreshold[percentage]": 30
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "setAutoCompaction" in path


# ── Alerts ────────────────────────────────────────────────────────────────────

class TestAlerts:
    def test_get_calls_endpoint(self, admin_mock):
        clust.handle("admin_alerts_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/alerts")

    def test_set_posts_to_endpoint(self, admin_mock):
        clust.handle("admin_alerts_set", {"enabled": True, "sender": "cb@example.com"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "alerts" in path

    def test_set_converts_bool_to_string(self, admin_mock):
        clust.handle("admin_alerts_set", {"enabled": True})
        data = admin_mock.call_args[1]["data"]
        assert data["enabled"] == "true"

    def test_test_email_posts(self, admin_mock):
        clust.handle("admin_alerts_test_email", {})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "sendTestEmail" in path


# ── Tool registration ─────────────────────────────────────────────────────────

class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in clust.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown cluster tool"):
            clust.handle("admin_cluster_nope", {})
