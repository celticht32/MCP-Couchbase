"""tests/test_security.py – Unit tests for handlers/security.py"""

from __future__ import annotations

import pytest

import handlers.security as sec
from conftest import parse_response


# ── Users ─────────────────────────────────────────────────────────────────────

class TestUserList:
    def test_lists_local_users_by_default(self, admin_mock):
        admin_mock.return_value = []
        sec.handle("admin_user_list", {})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/users/local")

    def test_lists_external_users_when_requested(self, admin_mock):
        sec.handle("admin_user_list", {"domain": "external"})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/users/external")


class TestUserGet:
    def test_calls_correct_endpoint(self, admin_mock):
        admin_mock.return_value = {"id": "alice"}
        sec.handle("admin_user_get", {"username": "alice"})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/users/local/alice")

    def test_uses_external_domain(self, admin_mock):
        sec.handle("admin_user_get", {"domain": "external", "username": "bob"})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/users/external/bob")


class TestUserCreate:
    def test_puts_to_local_users_endpoint(self, admin_mock):
        sec.handle("admin_user_create", {
            "username": "alice",
            "password": "s3cr3t",
            "roles":    "admin",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "PUT"
        assert "/settings/rbac/users/local/alice" == path

    def test_includes_required_fields(self, admin_mock):
        sec.handle("admin_user_create", {
            "username": "alice",
            "password": "p",
            "roles":    "bucket_admin[default]",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["password"] == "p"
        assert data["roles"]    == "bucket_admin[default]"

    def test_includes_display_name_when_provided(self, admin_mock):
        sec.handle("admin_user_create", {
            "username": "alice",
            "password": "p",
            "roles":    "admin",
            "name":     "Alice Smith",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["name"] == "Alice Smith"

    def test_includes_groups_when_provided(self, admin_mock):
        sec.handle("admin_user_create", {
            "username": "alice",
            "password": "p",
            "roles":    "admin",
            "groups":   "dev-team",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["groups"] == "dev-team"


class TestUserDelete:
    def test_sends_delete_request(self, admin_mock):
        sec.handle("admin_user_delete", {"username": "alice"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "alice" in path

    def test_respects_domain(self, admin_mock):
        sec.handle("admin_user_delete", {"domain": "external", "username": "bob"})
        _, path = admin_mock.call_args[0][:2]
        assert "external" in path


class TestUserChangePassword:
    def test_puts_password(self, admin_mock):
        sec.handle("admin_user_change_password", {
            "username": "alice", "password": "newpass"
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "PUT"
        assert "alice" in path
        data = admin_mock.call_args[1]["data"]
        assert data["password"] == "newpass"


# ── Groups ────────────────────────────────────────────────────────────────────

class TestGroupList:
    def test_calls_groups_endpoint(self, admin_mock):
        admin_mock.return_value = []
        sec.handle("admin_group_list", {})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/groups")


class TestGroupGet:
    def test_calls_group_by_name(self, admin_mock):
        sec.handle("admin_group_get", {"group_name": "dev-team"})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/groups/dev-team")


class TestGroupCreate:
    def test_puts_to_group_endpoint(self, admin_mock):
        sec.handle("admin_group_create", {
            "group_name": "dev-team",
            "roles":      "query_select[default]",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "PUT"
        assert "dev-team" in path

    def test_includes_roles_in_data(self, admin_mock):
        sec.handle("admin_group_create", {
            "group_name": "g",
            "roles":      "admin",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["roles"] == "admin"

    def test_includes_description_when_provided(self, admin_mock):
        sec.handle("admin_group_create", {
            "group_name":  "g",
            "roles":       "admin",
            "description": "My group",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["description"] == "My group"


class TestGroupDelete:
    def test_deletes_group(self, admin_mock):
        sec.handle("admin_group_delete", {"group_name": "old-group"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "old-group" in path


# ── Roles ─────────────────────────────────────────────────────────────────────

class TestRoleList:
    def test_calls_roles_endpoint(self, admin_mock):
        admin_mock.return_value = [{"role": "admin"}]
        sec.handle("admin_role_list", {})
        admin_mock.assert_called_once_with("GET", "/settings/rbac/roles")


# ── Who am I ─────────────────────────────────────────────────────────────────

class TestWhoAmI:
    def test_calls_whoami_endpoint(self, admin_mock):
        admin_mock.return_value = {"id": "Administrator", "roles": []}
        sec.handle("admin_whoami", {})
        admin_mock.assert_called_once_with("GET", "/whoami")


# ── Audit ─────────────────────────────────────────────────────────────────────

class TestAudit:
    def test_get_calls_correct_endpoint(self, admin_mock):
        sec.handle("admin_audit_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/audit")

    def test_set_posts_to_endpoint(self, admin_mock):
        sec.handle("admin_audit_set", {"auditdEnabled": True})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert path == "/settings/audit"

    def test_set_excludes_none_values(self, admin_mock):
        sec.handle("admin_audit_set", {
            "auditdEnabled": True,
            "logPath":       None,
        })
        data = admin_mock.call_args[1]["data"]
        assert "logPath" not in data


# ── Password policy ───────────────────────────────────────────────────────────

class TestPasswordPolicy:
    def test_get_calls_correct_endpoint(self, admin_mock):
        sec.handle("admin_password_policy_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/passwordPolicy")

    def test_set_posts_policy(self, admin_mock):
        sec.handle("admin_password_policy_set", {"minLength": 12})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "passwordPolicy" in path


# ── Security settings ─────────────────────────────────────────────────────────

class TestSecuritySettings:
    def test_get_calls_correct_endpoint(self, admin_mock):
        sec.handle("admin_security_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/security")

    def test_set_posts_settings(self, admin_mock):
        sec.handle("admin_security_settings_set", {"tlsMinVersion": "tlsv1.3"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "security" in path


# ── Tool registration ─────────────────────────────────────────────────────────

class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in sec.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown security tool"):
            sec.handle("admin_security_nope", {})
