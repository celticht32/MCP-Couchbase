"""tests/test_search_admin.py – Unit tests for handlers/search_admin.py"""

from __future__ import annotations

import pytest
from unittest.mock import call, patch

import handlers.search_admin as fts
from conftest import parse_response


# ── admin_fts_index_list ──────────────────────────────────────────────────────

class TestFtsIndexList:
    def test_calls_api_index_endpoint(self, admin_mock):
        admin_mock.return_value = {"indexDefs": {}}
        fts.handle("admin_fts_index_list", {})
        admin_mock.assert_called_once_with("GET", "/api/index")


# ── admin_fts_index_get ───────────────────────────────────────────────────────

class TestFtsIndexGet:
    def test_calls_named_index_endpoint(self, admin_mock):
        admin_mock.return_value = {"indexDef": {}}
        fts.handle("admin_fts_index_get", {"index_name": "my-fts"})
        admin_mock.assert_called_once_with("GET", "/api/index/my-fts")


# ── admin_fts_index_create ────────────────────────────────────────────────────

class TestFtsIndexCreate:
    def test_puts_to_named_endpoint(self, admin_mock):
        arj = admin_mock.json
        fts.handle("admin_fts_index_create", {
            "index_name": "hotel-search",
            "definition": {"type": "fulltext-index", "sourceName": "travel-sample"},
        })
        arj.assert_called_once()
        method, path = arj.call_args[0][:2]
        assert method == "PUT"
        assert "hotel-search" in path

    def test_sets_name_in_definition_if_missing(self, admin_mock):
        arj = admin_mock.json
        fts.handle("admin_fts_index_create", {
            "index_name": "hotel-search",
            "definition": {"type": "fulltext-index"},
        })
        payload = arj.call_args[1]["payload"]
        assert payload["name"] == "hotel-search"

    def test_does_not_overwrite_existing_name(self, admin_mock):
        arj = admin_mock.json
        fts.handle("admin_fts_index_create", {
            "index_name": "x",
            "definition": {"name": "explicit-name"},
        })
        payload = arj.call_args[1]["payload"]
        assert payload["name"] == "explicit-name"


# ── admin_fts_index_delete ────────────────────────────────────────────────────

class TestFtsIndexDelete:
    def test_sends_delete(self, admin_mock):
        fts.handle("admin_fts_index_delete", {"index_name": "old-fts"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "old-fts" in path


# ── admin_fts_index_stats ─────────────────────────────────────────────────────

class TestFtsIndexStats:
    def test_calls_stats_endpoint(self, admin_mock):
        fts.handle("admin_fts_index_stats", {"index_name": "my-fts"})
        admin_mock.assert_called_once_with("GET", "/api/index/my-fts/stats")


# ── admin_fts_index_doc_count ─────────────────────────────────────────────────

class TestFtsIndexDocCount:
    def test_calls_count_endpoint(self, admin_mock):
        admin_mock.return_value = {"count": 1234}
        fts.handle("admin_fts_index_doc_count", {"index_name": "my-fts"})
        admin_mock.assert_called_once_with("GET", "/api/index/my-fts/count")


# ── admin_fts_index_ingest_pause / resume ─────────────────────────────────────

class TestFtsIngestControl:
    def test_pause_posts_to_pause(self, admin_mock):
        fts.handle("admin_fts_index_ingest_pause", {"index_name": "my-fts"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "pause" in path
        assert "my-fts" in path

    def test_resume_posts_to_resume(self, admin_mock):
        fts.handle("admin_fts_index_ingest_resume", {"index_name": "my-fts"})
        _, path = admin_mock.call_args[0][:2]
        assert "resume" in path


# ── admin_fts_settings_get ────────────────────────────────────────────────────

class TestFtsSettings:
    def test_calls_cfg_endpoint(self, admin_mock):
        fts.handle("admin_fts_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/api/cfg")


# ── Tool registration ─────────────────────────────────────────────────────────

class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in fts.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown FTS admin tool"):
            fts.handle("admin_fts_nope", {})
