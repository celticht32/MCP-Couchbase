"""tests/test_shared.py – Unit tests for handlers/shared.py"""

from __future__ import annotations

import json
import os
import urllib.error
from io import BytesIO
from unittest.mock import MagicMock, patch

import pytest

import handlers.shared as sh
from conftest import parse_response


# ── _admin_url ────────────────────────────────────────────────────────────────

class TestAdminUrl:
    def test_default_http(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        assert sh._admin_url() == "http://localhost:8091"

    def test_tls_scheme(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbases://cb.cloud.example.com")
        monkeypatch.setenv("CB_MGMT_PORT", "18091")
        assert sh._admin_url() == "https://cb.cloud.example.com:18091"

    def test_custom_port(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://10.0.0.1")
        monkeypatch.setenv("CB_MGMT_PORT", "9999")
        assert sh._admin_url() == "http://10.0.0.1:9999"

    def test_strips_port_from_connection_string(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://10.0.0.1:11210")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        assert sh._admin_url() == "http://10.0.0.1:8091"


# ── ok / err helpers ──────────────────────────────────────────────────────────

class TestResponseHelpers:
    def test_ok_serialises_dict(self):
        result = sh.ok({"key": "val", "num": 42})
        assert len(result) == 1
        data = json.loads(result[0].text)
        assert data == {"key": "val", "num": 42}

    def test_ok_serialises_list(self):
        result = sh.ok([1, 2, 3])
        data = json.loads(result[0].text)
        assert data == [1, 2, 3]

    def test_ok_handles_non_serialisable_via_default(self):
        from datetime import datetime
        result = sh.ok({"ts": datetime(2024, 1, 1)})
        data = json.loads(result[0].text)
        assert "ts" in data  # stringified

    def test_err_wraps_message(self):
        result = sh.err("something went wrong")
        data = json.loads(result[0].text)
        assert data == {"error": "something went wrong"}

    def test_err_returns_single_content(self):
        result = sh.err("boom")
        assert len(result) == 1


# ── get_env ───────────────────────────────────────────────────────────────────

class TestGetEnv:
    def test_returns_env_value(self, monkeypatch):
        monkeypatch.setenv("CB_BUCKET", "my-bucket")
        assert sh.get_env("CB_BUCKET", "default") == "my-bucket"

    def test_returns_default_when_missing(self, monkeypatch):
        monkeypatch.delenv("CB_BUCKET", raising=False)
        assert sh.get_env("CB_BUCKET", "default") == "default"


# ── admin_request error handling ──────────────────────────────────────────────

class TestAdminRequest:
    def _make_http_error(self, code: int, body: bytes) -> urllib.error.HTTPError:
        fp = BytesIO(body)
        fp.read = lambda: body          # HTTPError.read()
        err = urllib.error.HTTPError(
            url="http://x", code=code, msg="err", hdrs={}, fp=fp
        )
        err.read = lambda: body
        return err

    def test_raises_runtime_on_http_error(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "Administrator")
        monkeypatch.setenv("CB_PASSWORD", "password")

        http_err = self._make_http_error(403, b'{"message":"Forbidden"}')

        with patch("urllib.request.urlopen", side_effect=http_err):
            with pytest.raises(RuntimeError, match="HTTP 403"):
                sh.admin_request("GET", "/pools")

    def test_raises_runtime_on_non_json_error_body(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "Administrator")
        monkeypatch.setenv("CB_PASSWORD", "password")

        http_err = self._make_http_error(500, b"Internal Server Error")
        with patch("urllib.request.urlopen", side_effect=http_err):
            with pytest.raises(RuntimeError, match="HTTP 500"):
                sh.admin_request("GET", "/pools")

    def test_returns_empty_dict_on_no_body(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "Administrator")
        monkeypatch.setenv("CB_PASSWORD", "password")

        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__  = MagicMock(return_value=False)
        mock_resp.read.return_value = b""

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = sh.admin_request("POST", "/some/endpoint")
        assert result == {"status": "ok"}

    def test_parses_json_response(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "Administrator")
        monkeypatch.setenv("CB_PASSWORD", "password")

        payload = json.dumps({"pools": []}).encode()
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__  = MagicMock(return_value=False)
        mock_resp.read.return_value = payload

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = sh.admin_request("GET", "/pools")
        assert result == {"pools": []}

    def test_includes_basic_auth_header(self, monkeypatch):
        import base64
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "testuser")
        monkeypatch.setenv("CB_PASSWORD", "testpass")

        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__  = MagicMock(return_value=False)
        mock_resp.read.return_value = b"{}"

        captured_req = {}

        def capture_urlopen(req, timeout=None):
            captured_req["req"] = req
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=capture_urlopen):
            sh.admin_request("GET", "/pools")

        auth_header = captured_req["req"].get_header("Authorization")
        expected    = "Basic " + base64.b64encode(b"testuser:testpass").decode()
        assert auth_header == expected

    def test_appends_query_params(self, monkeypatch):
        monkeypatch.setenv("CB_CONNECTION_STRING", "couchbase://localhost")
        monkeypatch.setenv("CB_MGMT_PORT", "8091")
        monkeypatch.setenv("CB_USERNAME", "Administrator")
        monkeypatch.setenv("CB_PASSWORD", "password")

        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__  = MagicMock(return_value=False)
        mock_resp.read.return_value = b"{}"

        captured = {}

        def capture(req, timeout=None):
            captured["url"] = req.full_url
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=capture):
            sh.admin_request("GET", "/stats", params={"step": 60})

        assert "step=60" in captured["url"]
