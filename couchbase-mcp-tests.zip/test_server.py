"""
tests/test_server.py – Integration tests for server.py tool routing.

Verifies that:
  - All 105 tools are registered in _ALL_TOOLS with unique names
  - Every tool name maps to a handler in _HANDLERS
  - The async call_tool dispatcher routes to the correct module
  - Unknown tool names return an error response (not an exception)
  - Tool schemas are structurally valid (have type, properties)
"""

from __future__ import annotations

import asyncio
import json
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

import server
from handlers import (
    data, buckets, collections, security,
    cluster, xdcr, indexes, search_admin, stats,
)
from conftest import parse_response


# ── Tool registry ─────────────────────────────────────────────────────────────

class TestToolRegistry:
    def test_total_tool_count(self):
        assert len(server._ALL_TOOLS) == 105

    def test_all_tool_names_unique(self):
        names = [t.name for t in server._ALL_TOOLS]
        dupes = [n for n in names if names.count(n) > 1]
        assert dupes == [], f"Duplicate tool names: {dupes}"

    def test_every_tool_has_a_handler(self):
        for tool in server._ALL_TOOLS:
            assert tool.name in server._HANDLERS, \
                f"No handler registered for tool '{tool.name}'"

    def test_handler_map_covers_all_tools(self):
        tool_names    = {t.name for t in server._ALL_TOOLS}
        handler_names = set(server._HANDLERS.keys())
        assert tool_names == handler_names

    def test_expected_module_assignments(self):
        """Spot-check that each category maps to the correct handler module."""
        checks = {
            "cb_get":                  data,
            "admin_bucket_create":     buckets,
            "admin_scope_list":        collections,
            "admin_user_create":       security,
            "admin_cluster_info":      cluster,
            "admin_xdcr_references_list": xdcr,
            "admin_index_create":      indexes,
            "admin_fts_index_list":    search_admin,
            "admin_stats_bucket":      stats,
        }
        for name, expected_module in checks.items():
            assert server._HANDLERS[name] is expected_module, \
                f"'{name}' should map to {expected_module.__name__}"


# ── Tool schema validation ─────────────────────────────────────────────────────

class TestToolSchemas:
    def test_all_tools_have_non_empty_description(self):
        for t in server._ALL_TOOLS:
            assert t.description and t.description.strip(), \
                f"{t.name} has an empty description"

    def test_all_tools_have_object_schema(self):
        for t in server._ALL_TOOLS:
            assert t.inputSchema.get("type") == "object", \
                f"{t.name} inputSchema type is not 'object'"

    def test_all_tools_have_properties_key(self):
        for t in server._ALL_TOOLS:
            assert "properties" in t.inputSchema, \
                f"{t.name} inputSchema missing 'properties'"

    def test_required_fields_exist_in_properties(self):
        for t in server._ALL_TOOLS:
            required = t.inputSchema.get("required", [])
            props    = t.inputSchema.get("properties", {})
            for field in required:
                assert field in props, \
                    f"{t.name}: required field '{field}' not listed in properties"


# ── call_tool dispatcher ──────────────────────────────────────────────────────

class TestCallToolDispatcher:
    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    def test_unknown_tool_returns_error_not_exception(self):
        result = self._run(server.call_tool("cb_does_not_exist", {}))
        data   = parse_response(result)
        assert "error" in data
        assert "cb_does_not_exist" in data["error"]

    def test_routes_to_correct_handler(self, sdk_mocks):
        """cb_ping dispatches to the data handler and returns ok."""
        result = self._run(server.call_tool("cb_ping", {}))
        data   = parse_response(result)
        assert data["status"] == "ok"

    def test_admin_tool_routes_correctly(self, admin_mock):
        """admin_bucket_list dispatches to buckets handler."""
        admin_mock.return_value = [{"name": "default"}]
        result = self._run(server.call_tool("admin_bucket_list", {}))
        data   = parse_response(result)
        assert isinstance(data, list)

    def test_handler_exception_becomes_error_response(self, sdk_mocks):
        """If the handler raises, the dispatcher returns an error dict."""
        cluster, _, _ = sdk_mocks
        cluster.ping.side_effect = RuntimeError("boom")
        result = self._run(server.call_tool("cb_ping", {}))
        data   = parse_response(result)
        assert "error" in data
        assert "boom" in data["error"]


# ── list_tools endpoint ───────────────────────────────────────────────────────

class TestListTools:
    def test_returns_all_tools(self):
        result = asyncio.get_event_loop().run_until_complete(server.list_tools())
        assert len(result) == 105

    def test_returns_tool_objects(self):
        from mcp.types import Tool
        result = asyncio.get_event_loop().run_until_complete(server.list_tools())
        assert all(isinstance(t, Tool) for t in result)
