"""tests/test_buckets.py – Unit tests for handlers/buckets.py"""

from __future__ import annotations

from unittest.mock import call, patch

import pytest

import handlers.buckets as bkt
from conftest import parse_response


# ── Helpers ───────────────────────────────────────────────────────────────────

def _handle(name, args=None, *, admin_mock):
    """Thin wrapper: set admin_mock return value, call handler, return parsed JSON."""
    return bkt.handle(name, args or {})


# ── admin_bucket_list ─────────────────────────────────────────────────────────

class TestBucketList:
    def test_calls_get_on_buckets_endpoint(self, admin_mock):
        admin_mock.return_value = [{"name": "default"}]
        bkt.handle("admin_bucket_list", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/buckets")

    def test_returns_list(self, admin_mock):
        admin_mock.return_value = [{"name": "b1"}, {"name": "b2"}]
        result = bkt.handle("admin_bucket_list", {})
        data   = parse_response(result)
        assert isinstance(data, list)
        assert len(data) == 2


# ── admin_bucket_get ──────────────────────────────────────────────────────────

class TestBucketGet:
    def test_calls_correct_path(self, admin_mock):
        admin_mock.return_value = {"name": "travel-sample"}
        bkt.handle("admin_bucket_get", {"bucket_name": "travel-sample"})
        admin_mock.assert_called_once_with("GET", "/pools/default/buckets/travel-sample")

    def test_returns_bucket_info(self, admin_mock):
        admin_mock.return_value = {"name": "travel-sample", "ramQuotaMB": 256}
        result = bkt.handle("admin_bucket_get", {"bucket_name": "travel-sample"})
        data   = parse_response(result)
        assert data["name"] == "travel-sample"


# ── admin_bucket_create ───────────────────────────────────────────────────────

class TestBucketCreate:
    def test_posts_to_buckets_endpoint(self, admin_mock):
        bkt.handle("admin_bucket_create", {
            "name": "new-bucket", "ramQuota": 256
        })
        admin_mock.assert_called_once()
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert path   == "/pools/default/buckets"

    def test_renames_ramquota_to_ramquotamb(self, admin_mock):
        bkt.handle("admin_bucket_create", {
            "name": "b", "ramQuota": 512
        })
        kwargs = admin_mock.call_args[1]
        assert "ramQuotaMB" in kwargs["data"]
        assert "ramQuota"   not in kwargs["data"]

    def test_includes_bucket_type(self, admin_mock):
        bkt.handle("admin_bucket_create", {
            "name": "b", "ramQuota": 256, "bucketType": "ephemeral"
        })
        data = admin_mock.call_args[1]["data"]
        assert data["bucketType"] == "ephemeral"

    def test_optional_fields_are_passed(self, admin_mock):
        bkt.handle("admin_bucket_create", {
            "name":          "b",
            "ramQuota":      256,
            "replicaNumber": 2,
            "flushEnabled":  1,
        })
        data = admin_mock.call_args[1]["data"]
        assert data["replicaNumber"] == 2
        assert data["flushEnabled"]  == 1


# ── admin_bucket_update ───────────────────────────────────────────────────────

class TestBucketUpdate:
    def test_posts_to_named_bucket(self, admin_mock):
        bkt.handle("admin_bucket_update", {
            "bucket_name": "my-bucket", "ramQuota": 512
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "my-bucket" in path

    def test_renames_ramquota(self, admin_mock):
        bkt.handle("admin_bucket_update", {
            "bucket_name": "b", "ramQuota": 1024
        })
        data = admin_mock.call_args[1]["data"]
        assert "ramQuotaMB" in data

    def test_excludes_none_values(self, admin_mock):
        bkt.handle("admin_bucket_update", {
            "bucket_name":   "b",
            "replicaNumber": None,
            "ramQuota":      256,
        })
        data = admin_mock.call_args[1]["data"]
        assert "replicaNumber" not in data


# ── admin_bucket_delete ───────────────────────────────────────────────────────

class TestBucketDelete:
    def test_sends_delete_request(self, admin_mock):
        bkt.handle("admin_bucket_delete", {"bucket_name": "old-bucket"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "old-bucket" in path


# ── admin_bucket_flush ────────────────────────────────────────────────────────

class TestBucketFlush:
    def test_posts_to_flush_endpoint(self, admin_mock):
        bkt.handle("admin_bucket_flush", {"bucket_name": "my-bucket"})
        _, path = admin_mock.call_args[0][:2]
        assert "doFlush" in path
        assert "my-bucket" in path


# ── admin_bucket_compact ──────────────────────────────────────────────────────

class TestBucketCompact:
    def test_posts_to_compact_endpoint(self, admin_mock):
        bkt.handle("admin_bucket_compact", {"bucket_name": "my-bucket"})
        _, path = admin_mock.call_args[0][:2]
        assert "compactBucket" in path

    def test_cancel_posts_to_cancel_endpoint(self, admin_mock):
        bkt.handle("admin_bucket_cancel_compaction", {"bucket_name": "my-bucket"})
        _, path = admin_mock.call_args[0][:2]
        assert "cancelBucketCompaction" in path


# ── admin_sample_buckets_list ─────────────────────────────────────────────────

class TestSampleBuckets:
    def test_list_calls_correct_endpoint(self, admin_mock):
        admin_mock.return_value = [{"name": "travel-sample", "installed": True}]
        bkt.handle("admin_sample_buckets_list", {})
        admin_mock.assert_called_once_with("GET", "/sampleBuckets")


# ── Tool registration ─────────────────────────────────────────────────────────

class TestToolRegistration:
    def test_unique_tool_names(self):
        names = [t.name for t in bkt.TOOLS]
        assert len(names) == len(set(names))

    def test_expected_tools_present(self):
        names = {t.name for t in bkt.TOOLS}
        required = {
            "admin_bucket_list", "admin_bucket_get", "admin_bucket_create",
            "admin_bucket_update", "admin_bucket_delete", "admin_bucket_flush",
            "admin_bucket_compact", "admin_bucket_cancel_compaction",
            "admin_sample_buckets_list", "admin_sample_buckets_install",
        }
        assert required.issubset(names)

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown bucket tool"):
            bkt.handle("admin_bucket_nonexistent", {})
