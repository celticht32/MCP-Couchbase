"""tests/test_indexes.py – Unit tests for handlers/indexes.py"""

from __future__ import annotations

import pytest
from unittest.mock import patch, MagicMock

import handlers.indexes as idx
from conftest import parse_response


# ── Helpers ───────────────────────────────────────────────────────────────────

def _setup_query_mock(sdk_mocks):
    """Configure cluster.query to return two rows."""
    cluster, _, _ = sdk_mocks
    return cluster


# ── admin_index_list ──────────────────────────────────────────────────────────

class TestIndexList:
    def test_queries_system_indexes(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {})
        stmt = cluster.query.call_args[0][0]
        assert "system:indexes" in stmt

    def test_no_where_clause_when_no_filters(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {})
        stmt = cluster.query.call_args[0][0]
        assert "WHERE" not in stmt

    def test_adds_bucket_filter(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {"bucket_name": "travel-sample"})
        stmt = cluster.query.call_args[0][0]
        assert "bucket_id" in stmt
        assert "travel-sample" in stmt

    def test_adds_scope_filter(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {"scope_name": "inventory"})
        stmt = cluster.query.call_args[0][0]
        assert "scope_id" in stmt

    def test_adds_collection_filter(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {"collection_name": "hotel"})
        stmt = cluster.query.call_args[0][0]
        assert "keyspace_id" in stmt

    def test_combines_multiple_filters_with_and(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_list", {
            "bucket_name": "b",
            "scope_name":  "s",
        })
        stmt = cluster.query.call_args[0][0]
        assert " AND " in stmt


# ── admin_index_create ────────────────────────────────────────────────────────

class TestIndexCreate:
    def test_uses_raw_statement_when_provided(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        raw = "CREATE INDEX `my_idx` ON `b`(`field`)"
        idx.handle("admin_index_create", {"statement": raw})
        stmt = cluster.query.call_args[0][0]
        assert stmt == raw

    def test_builds_secondary_index_from_fields(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_create", {
            "bucket_name": "b",
            "scope_name":  "s",
            "collection_name": "c",
            "index_name":  "idx_email",
            "fields":      ["email"],
        })
        stmt = cluster.query.call_args[0][0]
        assert "CREATE INDEX" in stmt
        assert "idx_email" in stmt
        assert "email" in stmt

    def test_builds_primary_index(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_create", {
            "bucket_name":  "b",
            "scope_name":   "s",
            "collection_name": "c",
            "is_primary":   True,
        })
        stmt = cluster.query.call_args[0][0]
        assert "PRIMARY INDEX" in stmt

    def test_adds_with_clause_for_num_replica(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_create", {
            "bucket_name": "b",
            "index_name":  "i",
            "fields":      ["x"],
            "num_replica": 2,
        })
        stmt = cluster.query.call_args[0][0]
        assert "WITH" in stmt
        assert "num_replica" in stmt

    def test_adds_defer_build_with_clause(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_create", {
            "bucket_name": "b",
            "index_name":  "i",
            "fields":      ["x"],
            "defer_build": True,
        })
        stmt = cluster.query.call_args[0][0]
        assert "defer_build" in stmt

    def test_defaults_scope_and_collection_to_default(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_create", {
            "bucket_name": "b",
            "index_name":  "i",
            "fields":      ["x"],
        })
        stmt = cluster.query.call_args[0][0]
        assert "_default" in stmt


# ── admin_index_drop ──────────────────────────────────────────────────────────

class TestIndexDrop:
    def test_uses_raw_statement_when_provided(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        raw = "DROP INDEX `i` ON `b`"
        idx.handle("admin_index_drop", {"statement": raw})
        stmt = cluster.query.call_args[0][0]
        assert stmt == raw

    def test_builds_drop_secondary_index(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_drop", {
            "bucket_name": "b",
            "index_name":  "my_idx",
        })
        stmt = cluster.query.call_args[0][0]
        assert "DROP INDEX" in stmt
        assert "my_idx" in stmt

    def test_builds_drop_primary_index(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_drop", {
            "bucket_name": "b",
            "is_primary":  True,
        })
        stmt = cluster.query.call_args[0][0]
        assert "DROP PRIMARY INDEX" in stmt


# ── admin_index_build ─────────────────────────────────────────────────────────

class TestIndexBuild:
    def test_builds_correct_statement(self, sdk_mocks):
        cluster, _, _ = sdk_mocks
        idx.handle("admin_index_build", {
            "bucket_name": "b",
            "index_names": ["idx1", "idx2"],
        })
        stmt = cluster.query.call_args[0][0]
        assert "BUILD INDEX" in stmt
        assert "idx1" in stmt
        assert "idx2" in stmt
        assert "b" in stmt


# ── admin_index_settings_get / set ───────────────────────────────────────────

class TestIndexSettings:
    def test_get_calls_correct_endpoint(self, sdk_mocks, admin_mock):
        idx.handle("admin_index_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/indexes")

    def test_set_posts_to_endpoint(self, sdk_mocks, admin_mock):
        idx.handle("admin_index_settings_set", {"indexerThreads": 4})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "/settings/indexes" in path

    def test_set_excludes_none_values(self, sdk_mocks, admin_mock):
        idx.handle("admin_index_settings_set", {
            "indexerThreads": 4,
            "logLevel":       None,
        })
        data = admin_mock.call_args[1]["data"]
        assert "logLevel" not in data


# ── Tool registration ─────────────────────────────────────────────────────────

class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in idx.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, sdk_mocks):
        with pytest.raises(ValueError, match="Unknown index tool"):
            idx.handle("admin_index_nope", {})
