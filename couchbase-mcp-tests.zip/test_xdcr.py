"""tests/test_xdcr.py – Unit tests for handlers/xdcr.py"""

from __future__ import annotations

import pytest

import handlers.xdcr as xdcr
from conftest import parse_response


class TestXdcrReferenceList:
    def test_calls_remote_clusters_endpoint(self, admin_mock):
        admin_mock.return_value = []
        xdcr.handle("admin_xdcr_references_list", {})
        admin_mock.assert_called_once_with("GET", "/pools/default/remoteClusters")


class TestXdcrReferenceCreate:
    def test_posts_to_remote_clusters(self, admin_mock):
        xdcr.handle("admin_xdcr_reference_create", {
            "name":     "dr-cluster",
            "hostname": "10.1.0.5",
            "username": "Administrator",
            "password": "pass",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "/pools/default/remoteClusters" in path

    def test_includes_all_required_fields(self, admin_mock):
        xdcr.handle("admin_xdcr_reference_create", {
            "name":     "dr",
            "hostname": "10.1.0.5",
            "username": "admin",
            "password": "pass",
        })
        data = admin_mock.call_args[1]["data"]
        assert "name"     in data
        assert "hostname" in data
        assert "username" in data
        assert "password" in data

    def test_includes_encryption_when_provided(self, admin_mock):
        xdcr.handle("admin_xdcr_reference_create", {
            "name":               "dr",
            "hostname":           "10.1.0.5",
            "username":           "admin",
            "password":           "pass",
            "demandEncryption":   1,
        })
        data = admin_mock.call_args[1]["data"]
        assert "demandEncryption" in data


class TestXdcrReferenceDelete:
    def test_deletes_by_cluster_name(self, admin_mock):
        xdcr.handle("admin_xdcr_reference_delete", {"cluster_name": "dr-cluster"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "dr-cluster" in path


class TestXdcrReplicationsList:
    def test_calls_replications_endpoint(self, admin_mock):
        admin_mock.return_value = {}
        xdcr.handle("admin_xdcr_replications_list", {})
        admin_mock.assert_called_once_with("GET", "/settings/replications/")


class TestXdcrReplicationCreate:
    def test_posts_to_createReplication(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_create", {
            "fromBucket": "source",
            "toCluster":  "dr-cluster",
            "toBucket":   "source",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "createReplication" in path

    def test_includes_required_fields(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_create", {
            "fromBucket": "src",
            "toCluster":  "dr",
            "toBucket":   "tgt",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["fromBucket"] == "src"
        assert data["toCluster"]  == "dr"
        assert data["toBucket"]   == "tgt"

    def test_defaults_replication_type_to_continuous(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_create", {
            "fromBucket": "src",
            "toCluster":  "dr",
            "toBucket":   "tgt",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["replicationType"] == "continuous"

    def test_includes_filter_expression_when_provided(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_create", {
            "fromBucket":       "src",
            "toCluster":        "dr",
            "toBucket":         "tgt",
            "filterExpression": "type='hotel'",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["filterExpression"] == "type='hotel'"


class TestXdcrReplicationPauseResume:
    def test_pause_sets_pauseRequested_true(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_pause", {"replication_id": "abc123"})
        data = admin_mock.call_args[1]["data"]
        assert data["pauseRequested"] == "true"

    def test_resume_sets_pauseRequested_false(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_resume", {"replication_id": "abc123"})
        data = admin_mock.call_args[1]["data"]
        assert data["pauseRequested"] == "false"


class TestXdcrReplicationDelete:
    def test_deletes_replication(self, admin_mock):
        xdcr.handle("admin_xdcr_replication_delete", {"replication_id": "abc123"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "cancelXDCR" in path

    def test_url_encodes_replication_id(self, admin_mock):
        # IDs contain slashes that must be encoded
        xdcr.handle("admin_xdcr_replication_delete", {
            "replication_id": "abc/source/target"
        })
        _, path = admin_mock.call_args[0][:2]
        assert "/" not in path.split("cancelXDCR/", 1)[-1]


class TestXdcrSettings:
    def test_get_calls_replications_endpoint(self, admin_mock):
        xdcr.handle("admin_xdcr_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/replications/")

    def test_set_global_posts_to_replications(self, admin_mock):
        xdcr.handle("admin_xdcr_settings_set", {
            "workerBatchSize": 500,
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "replications" in path

    def test_set_per_replication_uses_id_in_path(self, admin_mock):
        xdcr.handle("admin_xdcr_settings_set", {
            "replication_id":  "myid",
            "workerBatchSize": 500,
        })
        _, path = admin_mock.call_args[0][:2]
        assert "myid" in path


class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in xdcr.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown XDCR tool"):
            xdcr.handle("admin_xdcr_nope", {})
