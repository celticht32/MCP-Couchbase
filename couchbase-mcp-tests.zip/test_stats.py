"""tests/test_stats.py – Unit tests for handlers/stats.py"""

from __future__ import annotations

import pytest
from unittest.mock import patch

import handlers.stats as stats
from conftest import parse_response


class TestStatsBucket:
    def test_calls_bucket_stats_endpoint(self, admin_mock):
        admin_mock.return_value = {"op": {}}
        stats.handle("admin_stats_bucket", {"bucket_name": "travel-sample"})
        admin_mock.assert_called_once_with(
            "GET", "/pools/default/buckets/travel-sample/stats"
        )


class TestStatsSingle:
    def test_calls_range_endpoint(self, admin_mock):
        admin_mock.return_value = []
        stats.handle("admin_stats_single", {"metric_name": "kv_num_items"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "GET"
        assert "kv_num_items" in path

    def test_passes_time_range_params(self, admin_mock):
        admin_mock.return_value = []
        stats.handle("admin_stats_single", {
            "metric_name": "kv_num_items",
            "start":       1700000000,
            "end":         1700003600,
            "step":        60,
        })
        params = admin_mock.call_args[1]["params"]
        assert params["start"] == 1700000000
        assert params["end"]   == 1700003600
        assert params["step"]  == 60

    def test_omits_params_when_not_provided(self, admin_mock):
        admin_mock.return_value = []
        stats.handle("admin_stats_single", {"metric_name": "n1ql_requests"})
        kwargs = admin_mock.call_args[1]
        # params key should be None or absent
        assert kwargs.get("params") is None


class TestStatsMulti:
    def test_posts_to_stats_range(self, admin_mock):
        arj = admin_mock.json
        stats.handle("admin_stats_multi", {"metrics": [{"metric": []}]})
        arj.assert_called_once()
        method, path = arj.call_args[0][:2]
        assert method == "POST"
        assert "/pools/default/stats/range" in path


class TestSystemEvents:
    def test_calls_events_endpoint(self, admin_mock):
        admin_mock.return_value = [{"id": 1}] * 5
        stats.handle("admin_system_events", {})
        admin_mock.assert_called_once_with("GET", "/events")

    def test_limits_results(self, admin_mock):
        admin_mock.return_value = list(range(100))
        result = stats.handle("admin_system_events", {"limit": 10})
        data   = parse_response(result)
        assert len(data) == 10

    def test_default_limit_is_50(self, admin_mock):
        admin_mock.return_value = list(range(200))
        result = stats.handle("admin_system_events", {})
        data   = parse_response(result)
        assert len(data) == 50


class TestNodeSelfInfo:
    def test_calls_nodes_self(self, admin_mock):
        stats.handle("admin_node_self_info", {})
        admin_mock.assert_called_once_with("GET", "/nodes/self")


class TestInternalSettings:
    def test_get_calls_internal_settings(self, admin_mock):
        stats.handle("admin_internal_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/internalSettings")

    def test_set_posts_to_internal_settings(self, admin_mock):
        stats.handle("admin_internal_settings_set", {
            "maxParallelIndexers": 4
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "internalSettings" in path

    def test_set_excludes_none_values(self, admin_mock):
        stats.handle("admin_internal_settings_set", {
            "maxParallelIndexers":        4,
            "maxParallelReplicaIndexers": None,
        })
        data = admin_mock.call_args[1]["data"]
        assert "maxParallelReplicaIndexers" not in data


class TestQuerySettings:
    def test_get_calls_querySettings_endpoint(self, admin_mock):
        stats.handle("admin_query_settings_get", {})
        admin_mock.assert_called_once_with("GET", "/settings/querySettings")

    def test_set_posts_to_querySettings(self, admin_mock):
        stats.handle("admin_query_settings_set", {"queryLogLevel": "info"})
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "querySettings" in path

    def test_set_stringifies_values(self, admin_mock):
        stats.handle("admin_query_settings_set", {
            "queryTimeout":       60000000000,
            "queryMaxParallelism": 4,
        })
        data = admin_mock.call_args[1]["data"]
        assert data["queryTimeout"]        == "60000000000"
        assert data["queryMaxParallelism"] == "4"


class TestPrometheusTargets:
    def test_calls_prometheus_sd_config(self, admin_mock):
        stats.handle("admin_prometheus_targets", {})
        admin_mock.assert_called_once_with("GET", "/prometheus_sd_config")


class TestToolRegistration:
    def test_unique_names(self):
        names = [t.name for t in stats.TOOLS]
        assert len(names) == len(set(names))

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown stats tool"):
            stats.handle("admin_stats_nope", {})
