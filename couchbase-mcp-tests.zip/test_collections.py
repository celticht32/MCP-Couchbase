"""tests/test_collections.py – Unit tests for handlers/collections.py"""

from __future__ import annotations

import pytest

import handlers.collections as col_handler
from conftest import parse_response


class TestScopeList:
    def test_calls_correct_endpoint(self, admin_mock):
        admin_mock.return_value = {"scopes": []}
        col_handler.handle("admin_scope_list", {"bucket_name": "my-bucket"})
        admin_mock.assert_called_once_with(
            "GET", "/pools/default/buckets/my-bucket/scopes/"
        )


class TestScopeCreate:
    def test_posts_to_scopes_endpoint(self, admin_mock):
        col_handler.handle("admin_scope_create", {
            "bucket_name": "my-bucket",
            "scope_name":  "my-scope",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "/pools/default/buckets/my-bucket/scopes" in path

    def test_passes_scope_name_as_data(self, admin_mock):
        col_handler.handle("admin_scope_create", {
            "bucket_name": "b",
            "scope_name":  "inventory",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["name"] == "inventory"


class TestScopeDelete:
    def test_sends_delete_request(self, admin_mock):
        col_handler.handle("admin_scope_delete", {
            "bucket_name": "b",
            "scope_name":  "old-scope",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "old-scope" in path


class TestCollectionCreate:
    def test_posts_to_collections_endpoint(self, admin_mock):
        col_handler.handle("admin_collection_create", {
            "bucket_name":     "b",
            "scope_name":      "s",
            "collection_name": "c",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "POST"
        assert "b" in path and "s" in path and "collections" in path

    def test_passes_collection_name(self, admin_mock):
        col_handler.handle("admin_collection_create", {
            "bucket_name":     "b",
            "scope_name":      "s",
            "collection_name": "orders",
        })
        data = admin_mock.call_args[1]["data"]
        assert data["name"] == "orders"

    def test_passes_maxttl_when_provided(self, admin_mock):
        col_handler.handle("admin_collection_create", {
            "bucket_name":     "b",
            "scope_name":      "s",
            "collection_name": "c",
            "maxTTL":          3600,
        })
        data = admin_mock.call_args[1]["data"]
        assert data["maxTTL"] == "3600"

    def test_omits_maxttl_when_not_provided(self, admin_mock):
        col_handler.handle("admin_collection_create", {
            "bucket_name":     "b",
            "scope_name":      "s",
            "collection_name": "c",
        })
        data = admin_mock.call_args[1]["data"]
        assert "maxTTL" not in data


class TestCollectionDelete:
    def test_sends_delete_request(self, admin_mock):
        col_handler.handle("admin_collection_delete", {
            "bucket_name":     "b",
            "scope_name":      "s",
            "collection_name": "c",
        })
        method, path = admin_mock.call_args[0][:2]
        assert method == "DELETE"
        assert "b" in path and "s" in path and "c" in path


class TestToolRegistration:
    def test_unique_tool_names(self):
        names = [t.name for t in col_handler.TOOLS]
        assert len(names) == len(set(names))

    def test_expected_tools_present(self):
        names = {t.name for t in col_handler.TOOLS}
        assert {"admin_scope_list", "admin_scope_create", "admin_scope_delete",
                "admin_collection_create", "admin_collection_delete"}.issubset(names)

    def test_unknown_tool_raises(self, admin_mock):
        with pytest.raises(ValueError, match="Unknown collection tool"):
            col_handler.handle("admin_collection_nope", {})
